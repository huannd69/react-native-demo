const constants = {
    BASE_URL: '',
    SERVER_TIMEOUT: 10000,
    
}

export default constants;