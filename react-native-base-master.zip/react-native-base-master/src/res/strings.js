const strings = {
    onboarding: {
        welcome: {
            heading: 'Welcome',
        },
        welcome1: {
            button: 'Login'
        },
    },

    
}
export default strings;